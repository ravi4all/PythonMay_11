import pygame

# Initialize pygame
pygame.init()

red = 255,180,0
black = 0,0,0

width = 1000
height = 500

screen = pygame.display.set_mode((width, height))

game_bg = pygame.image.load("images/background.png")

while True:
    for event in pygame.event.get():
        # print(event)
        if event.type == pygame.QUIT:
            pygame.quit()   # quit pygame
            quit()          # quit python

    screen.blit(game_bg, (0,0))
    pygame.display.update()